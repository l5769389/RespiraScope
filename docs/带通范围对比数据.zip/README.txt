带通范围扩展前后对比数据

14 种模拟场景，复用此前文档的相同原始样本，不是患者实测数据。
每个 CSV 共 3000 点，采样率 50 Hz，时间 0.00 至 59.98 秒。
raw：原始信号；original_bandpass：0.1 至 40/60 Hz；expanded_bandpass：0.03 至 2 Hz。
两组均使用项目 OfflineFilterStrategy，order=2，双向滤波，恢复原始中位数，Gaussian sigma=1.5，保留 1 位小数。
仅修改两个实际截止频率，未改变模拟参数、峰检测频率限制或数据幅值。
文档展示全段及 20 至 30 秒局部，同场景左右采用相同坐标尺度。首尾过渡保留可见。
完整参数及原始 JSON 校验值见 parameters.json。
